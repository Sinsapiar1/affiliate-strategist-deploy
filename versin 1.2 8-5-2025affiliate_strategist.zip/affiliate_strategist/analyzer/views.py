# analyzer/views.py

from django.shortcuts import render
from django.views import View
from django.http import JsonResponse, HttpResponse
from .models import AnalysisHistory, MarketingTemplate
from .utils.scraping import scrape_product_info
from .utils.ai_integration import detect_and_generate as generate_strategy
from .utils.pdf_generator import generate_strategy_pdf
from .models import CompetitorAnalysis  # Ya tienes este modelo
import re
import json

class AffiliateStrategistView(View):
    """Vista principal para la herramienta de marketing de afiliados"""
    
    def get(self, request):
        """Muestra el formulario principal con plantillas"""
        
        # Obtener plantillas ordenadas por éxito
        templates = MarketingTemplate.objects.all().order_by('-success_rate')[:6]
        
        context = {
            'platforms': [
                ('instagram', 'Instagram'),
                ('tiktok', 'TikTok'),
                ('facebook', 'Facebook'),
                ('youtube', 'YouTube'),
                ('blog', 'Blog/SEO'),
                ('email', 'Email Marketing'),
                ('twitter', 'Twitter/X'),
            ],
            'templates': templates,  # Agregar plantillas al contexto
        }
        return render(request, 'analyzer/index.html', context)
    
    def post(self, request):
            """REEMPLAZAR tu método post actual con esta versión mejorada"""
            try:
                # Detectar tipo de análisis
                analysis_type = request.POST.get('analysis_type', 'basic')
                
                if analysis_type == 'competitor':
                    return self.handle_competitive_analysis(request)
                else:
                    return self.handle_basic_analysis(request)
                    
            except Exception as e:
                return JsonResponse({
                    'success': False,
                    'error': str(e)
                })
        
    def handle_basic_analysis(self, request):
            """Tu lógica actual de análisis básico (MANTENER IGUAL)"""
            # Recibir TODOS los datos del formulario mejorado
            product_url = request.POST.get('product_url', '').strip()
            target_audience = request.POST.get('target_audience', '').strip()
            platform = request.POST.get('platform', '').strip()
            api_key = request.POST.get('api_key', '').strip()
            
            # Nuevos campos del formulario avanzado
            budget = request.POST.get('budget', 'low')
            campaign_goal = request.POST.get('campaign_goal', 'conversions')
            tone = request.POST.get('tone', 'professional')
            additional_context = request.POST.get('additional_context', '')
            
            # Validar campos obligatorios
            if not all([product_url, target_audience, platform, api_key]):
                return JsonResponse({
                    'success': False,
                    'error': 'Por favor completa todos los campos obligatorios.'
                })
            
            # Web Scraping
            scraping_result = scrape_product_info(product_url)
            if not scraping_result['success']:
                return JsonResponse({
                    'success': False,
                    'error': scraping_result['error']
                })
            
            # Generar prompt mejorado con todos los datos
            product_data = scraping_result['data']
            prompt = self.build_enhanced_prompt(
                product_data, 
                target_audience, 
                platform,
                budget,
                campaign_goal,
                tone,
                additional_context
            )
            
            # Llamar a IA
            ai_result = generate_strategy(prompt, api_key)
            if not ai_result['success']:
                return JsonResponse({
                    'success': False,
                    'error': ai_result['error']
                })
            
            # Guardar en historial con todos los campos nuevos
            analysis = AnalysisHistory.objects.create(
                product_url=product_url,
                target_audience=target_audience,
                platform=platform,
                product_title=product_data.get('title', ''),
                product_description=product_data.get('description', ''),
                product_price=product_data.get('price', ''),
                product_category=product_data.get('category', ''),
                estimated_budget=budget,
                ai_response=ai_result['response'],
                success=True
            )
            
            # IMPORTANTE: Incluir el ID del análisis en la respuesta
            return JsonResponse({
                'success': True,
                'response': ai_result['response'],
                'product_info': product_data,
                'analysis_id': analysis.id  # NECESARIO PARA EL PDF
            })
        
    def handle_competitive_analysis(self, request):
            """NUEVA función para análisis competitivo"""
            # Extraer datos del formulario competitivo
            main_product_url = request.POST.get('main_product_url', '').strip()
            target_audience = request.POST.get('target_audience', '').strip()
            platform = request.POST.get('platform', '').strip()
            api_key = request.POST.get('api_key', '').strip()
            analysis_focus = request.POST.get('analysis_focus', 'complete')
            
            # Validar campos básicos
            if not all([main_product_url, target_audience, platform, api_key]):
                return JsonResponse({
                    'success': False,
                    'error': 'Por favor completa todos los campos obligatorios.'
                })
            
            # Recopilar URLs de competidores
            competitor_urls = []
            for i in range(1, 6):  # Hasta 5 competidores
                competitor_url = request.POST.get(f'competitor_{i}')
                if competitor_url and competitor_url.strip():
                    competitor_urls.append(competitor_url.strip())
            
            if len(competitor_urls) < 2:
                return JsonResponse({
                    'success': False,
                    'error': 'Se requieren mínimo 2 competidores para el análisis.'
                })
            
            # Scraping del producto principal
            main_scraping = scrape_product_info(main_product_url)
            if not main_scraping['success']:
                return JsonResponse({
                    'success': False,
                    'error': f'Error al analizar tu producto: {main_scraping["error"]}'
                })
            
            main_product = main_scraping['data']
            
            # Scraping de competidores
            competitors_data = []
            for i, competitor_url in enumerate(competitor_urls, 1):
                competitor_scraping = scrape_product_info(competitor_url)
                if competitor_scraping['success']:
                    competitor_info = competitor_scraping['data']
                    competitor_info['competitor_number'] = i
                    competitor_info['url'] = competitor_url
                    competitors_data.append(competitor_info)
            
            if len(competitors_data) == 0:
                return JsonResponse({
                    'success': False,
                    'error': 'No se pudo extraer información de ningún competidor.'
                })
            
            # Generar análisis de precios
            pricing_analysis = self.analyze_competitive_pricing(main_product, competitors_data)
            
            # Generar prompt competitivo especializado
            competitive_prompt = self.build_competitive_prompt(
                main_product, 
                competitors_data, 
                target_audience, 
                platform,
                analysis_focus,
                pricing_analysis
            )
            
            # Llamar a IA con prompt competitivo
            ai_result = generate_strategy(competitive_prompt, api_key)
            if not ai_result['success']:
                return JsonResponse({
                    'success': False,
                    'error': ai_result['error']
                })
            
            # Guardar análisis principal
            analysis = AnalysisHistory.objects.create(
                product_url=main_product_url,
                target_audience=target_audience,
                platform=platform,
                product_title=main_product.get('title', ''),
                product_description=main_product.get('description', ''),
                product_price=main_product.get('price', ''),
                ai_response=ai_result['response'],
                competitor_analysis=pricing_analysis,  # Usar campo existente
                success=True
            )
            
            # Guardar datos de cada competidor usando tu modelo existente
            for competitor_data in competitors_data:
                CompetitorAnalysis.objects.create(
                    analysis=analysis,
                    competitor_url=competitor_data['url'],
                    competitor_name=competitor_data.get('title', 'Competidor sin nombre'),
                    strengths=['Producto establecido', 'Precio competitivo'],  # Placeholder
                    weaknesses=['Análisis detallado disponible'],  # Placeholder
                    strategies=['Estrategias identificadas por IA']  # Placeholder
                )
            
            return JsonResponse({
                'success': True,
                'response': ai_result['response'],
                'analysis_id': analysis.id,
                'analysis_type': 'competitive',
                'main_product': main_product,
                'competitors_analyzed': len(competitors_data),
                'pricing_analysis': pricing_analysis
            })
        
    def analyze_competitive_pricing(self, main_product, competitors_data):
            """Analiza precios competitivos"""
            try:
                main_price = self.extract_price_from_text(main_product.get('price', ''))
                competitor_prices = []
                
                for comp in competitors_data:
                    price = self.extract_price_from_text(comp.get('price', ''))
                    if price:
                        competitor_prices.append(price)
                
                if not competitor_prices:
                    return {
                        'position': 'unknown',
                        'recommendation': 'No se pudieron comparar precios'
                    }
                
                avg_price = sum(competitor_prices) / len(competitor_prices)
                
                if not main_price:
                    position = 'unknown'
                    recommendation = 'Verificar precio de tu producto'
                elif main_price < min(competitor_prices):
                    position = 'cheapest'
                    recommendation = 'Puedes aumentar precio o enfocar en valor'
                elif main_price > max(competitor_prices):
                    position = 'premium'
                    recommendation = 'Justificar precio premium con beneficios únicos'
                else:
                    position = 'competitive'
                    recommendation = 'Precio competitivo, enfocar en diferenciación'
                
                return {
                    'position': position,
                    'main_price': main_price,
                    'avg_competitor_price': avg_price,
                    'recommendation': recommendation
                }
                
            except Exception as e:
                return {
                    'position': 'error',
                    'recommendation': f'Error en análisis: {str(e)}'
                }
        
    def extract_price_from_text(self, price_text):
            """Extrae precio numérico de cualquier texto"""
            if not price_text:
                return None
            
            # Patrones para encontrar precios
            patterns = [
                r'\$(\d+(?:,\d{3})*(?:\.\d{2})?)',  # $123.45
                r'(\d+(?:,\d{3})*(?:\.\d{2})?)\s*\$',  # 123.45$
                r'(\d+(?:\.\d{2})?)',  # 123.45
            ]
            
            for pattern in patterns:
                match = re.search(pattern, str(price_text).replace(',', ''))
                if match:
                    try:
                        return float(match.group(1))
                    except ValueError:
                        continue
            return None
        
    def build_competitive_prompt(self, main_product, competitors, target_audience, 
                                platform, analysis_focus, pricing_analysis):
            """Construye prompt especializado para análisis competitivo"""
            
            # Información del producto principal
            main_info = f"""
    PRODUCTO PRINCIPAL:
    - Título: {main_product.get('title', 'N/A')}
    - Precio: {main_product.get('price', 'N/A')}
    - Descripción: {main_product.get('description', 'N/A')[:500]}
    """
            
            # Información de competidores
            competitors_info = "COMPETIDORES DIRECTOS:\n"
            for comp in competitors:
                competitors_info += f"""
    Competidor {comp['competitor_number']}:
    - Título: {comp.get('title', 'N/A')}
    - Precio: {comp.get('price', 'N/A')}
    - Descripción: {comp.get('description', 'N/A')[:300]}
    ---
    """
            
            # Prompt especializado
            prompt = f"""Eres un EXPERTO en competitive intelligence y marketing de afiliados agresivo.

    {main_info}

    {competitors_info}

    ANÁLISIS DE PRECIOS:
    Tu posición: {pricing_analysis.get('position', 'Indeterminada')}
    Recomendación: {pricing_analysis.get('recommendation', 'Analizar más datos')}

    AUDIENCIA: {target_audience}
    PLATAFORMA: {platform}
    ENFOQUE: {analysis_focus}

    GENERA un análisis competitivo DEMOLEDOR con este formato:

    # 🎯 POSICIONAMIENTO ESTRATÉGICO

    ## Tu Ventaja Competitiva Única
    [Identifica 2-3 ventajas específicas vs cada competidor]

    ## USP Ganadora
    [Una propuesta de valor que NINGÚN competidor está usando]

    # 💰 ESTRATEGIA DE PRECIOS Y VALOR

    ## Tu Posición en el Mercado
    [Análisis detallado de tu posición de precio]

    ## Cómo Justificar tu Precio
    [Argumentos específicos para tu precio vs competidores]

    # 🚀 GAPS DE MERCADO DETECTADOS

    ## 3 Oportunidades Inmediatas
    [Cosas que competidores NO están haciendo]

    ## Contenido que Falta
    [Tipos de contenido que puedes crear para diferenciarte]

    # ⚔️ PLAN DE ATAQUE ESPECÍFICO

    ## 3 Campañas para Robar Market Share
    [Campañas específicas con hooks y ángulos concretos]

    ## 5 Headlines Ganadoras
    [Headlines que superen directamente a competidores]

    # ⚡ QUICK WINS (Próximos 30 días)

    ## Semana 1-2: Acciones Inmediatas
    [3 acciones específicas basadas en debilidades detectadas]

    ## Semana 3-4: Consolidar Ventaja
    [Cómo dominar el espacio que competidores ignoran]

    Sé ESPECÍFICO, AGRESIVO y ACCIONABLE. Dame tácticas que pueda implementar HOY.
    """
            return prompt
    
    def build_enhanced_prompt(self, product_data, target_audience, platform, 
                            budget, campaign_goal, tone, additional_context):
        """Construye un prompt mejorado con todos los datos"""
        
        # Mapeo de valores a texto más descriptivo
        budget_text = {
            'low': 'presupuesto bajo ($0-100)',
            'medium': 'presupuesto medio ($100-500)',
            'high': 'presupuesto alto ($500+)'
        }.get(budget, 'presupuesto limitado')
        
        goal_text = {
            'awareness': 'generar conocimiento de marca',
            'traffic': 'generar tráfico al sitio',
            'conversions': 'maximizar conversiones y ventas',
            'engagement': 'aumentar el engagement'
        }.get(campaign_goal, 'generar ventas')
        
        tone_text = {
            'professional': 'profesional y confiable',
            'casual': 'casual y amigable',
            'humorous': 'humorístico y divertido',
            'inspirational': 'inspiracional y motivador',
            'urgent': 'urgente y directo'
        }.get(tone, 'profesional')
        
        prompt = f"""Eres un experto estratega en marketing de afiliados con 10+ años de experiencia. 
Genera una estrategia ESPECÍFICA y ACCIONABLE.

**PRODUCTO:**
- Título: {product_data.get('title', 'No disponible')}
- Descripción: {product_data.get('description', 'No disponible')[:500]}
- Precio: {product_data.get('price', 'No disponible')}
- Categoría: {product_data.get('category', 'General')}

**TARGET Y CONTEXTO:**
- Audiencia: {target_audience}
- Plataforma: {platform}
- Presupuesto: {budget_text}
- Objetivo principal: {goal_text}
- Tono de comunicación: {tone_text}
{f'- Contexto adicional: {additional_context}' if additional_context else ''}

**GENERA UNA ESTRATEGIA COMPLETA:**

### 📊 1. Análisis de Necesidades
Identifica las 3 necesidades principales que este producto resuelve para la audiencia objetivo.

### 🎯 2. Estrategia de Contenido para {platform}
Proporciona 2 ideas de contenido MUY específicas incluyendo:
- Titular que genere curiosidad
- Copy principal (adaptado al tono {tone_text})
- Call-to-action específico
- 3-5 hashtags relevantes

### 💡 3. Ángulos de Venta Psicológicos
- 2 pain points que el producto resuelve
- 2 deseos que el producto satisface
- 1 objeción común y cómo superarla

### 📱 4. Táctica de Implementación
Considerando el {budget_text}, sugiere:
- Mejor horario para publicar
- Frecuencia de publicaciones
- Tipo de contenido más efectivo

Sé MUY específico y proporciona ejemplos listos para usar."""

        return prompt

def history_view(request):
    """Vista del historial"""
    analyses = AnalysisHistory.objects.filter(success=True).order_by('-created_at')[:10]
    return render(request, 'analyzer/history.html', {'analyses': analyses})

# REEMPLAZAR tu función download_pdf en views.py

def download_pdf(request, analysis_id):
    """Descarga la estrategia en PDF - Detecta automáticamente el tipo"""
    try:
        # Obtener el análisis
        analysis = AnalysisHistory.objects.get(id=analysis_id)
        
        # Obtener tipo de análisis desde parámetro URL (opcional)
        analysis_type = request.GET.get('type', 'auto')
        
        # Generar PDF (el PDF generator ya detecta automáticamente el tipo)
        pdf_content = generate_strategy_pdf(analysis)
        
        # Crear respuesta HTTP con el PDF
        response = HttpResponse(pdf_content, content_type='application/pdf')
        
        # Determinar tipo para el nombre del archivo
        if analysis_type == 'competitive' or 'competitiv' in analysis.ai_response.lower():
            file_prefix = "analisis_competitivo"
        else:
            file_prefix = "estrategia_basica"
        
        # Nombre del archivo mejorado
        filename = f"{file_prefix}_{analysis.id}_{analysis.created_at.strftime('%Y%m%d_%H%M')}.pdf"
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        
        return response
        
    except AnalysisHistory.DoesNotExist:
        return HttpResponse("❌ Análisis no encontrado", status=404)
    except Exception as e:
        print(f"Error generando PDF: {e}")
        return HttpResponse("❌ Error generando PDF. Contacta soporte.", status=500)