# Analyzer app initialization
