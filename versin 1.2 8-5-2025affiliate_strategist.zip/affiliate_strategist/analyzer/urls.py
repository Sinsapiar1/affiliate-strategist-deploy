# analyzer/urls.py
from django.urls import path
from .views import AffiliateStrategistView, history_view, download_pdf

app_name = 'analyzer'

urlpatterns = [
    path('', AffiliateStrategistView.as_view(), name='home'),
    path('history/', history_view, name='history'),
    path('download-pdf/<int:analysis_id>/', download_pdf, name='download_pdf'),  # Nueva línea
]