# analyzer/models.py - VERSIÓN MEJORADA

from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

class AnalysisHistory(models.Model):
    """Modelo mejorado con más datos útiles"""
    
    # Usuario (para cuando agregues autenticación)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    
    # Datos básicos
    product_url = models.URLField(max_length=500)
    target_audience = models.TextField()
    platform = models.CharField(max_length=50, choices=[
        ('instagram', 'Instagram'),
        ('tiktok', 'TikTok'),
        ('facebook', 'Facebook'),
        ('youtube', 'YouTube'),
        ('blog', 'Blog'),
        ('email', 'Email Marketing'),
        ('twitter', 'Twitter/X'),
    ])
    
    # Datos del producto mejorados
    product_title = models.CharField(max_length=300, blank=True)
    product_description = models.TextField(blank=True)
    product_price = models.CharField(max_length=50, blank=True)
    product_image = models.URLField(blank=True)
    product_category = models.CharField(max_length=100, blank=True)
    product_rating = models.FloatField(null=True, blank=True)
    
    # Respuesta de IA
    ai_response = models.TextField(blank=True)
    
    # Métricas de engagement (para tracking)
    strategy_rating = models.IntegerField(null=True, blank=True)  # 1-5 estrellas
    was_implemented = models.BooleanField(default=False)
    conversion_rate = models.FloatField(null=True, blank=True)
    
    # Metadata
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    success = models.BooleanField(default=False)
    error_message = models.TextField(blank=True)
    
    # Nuevos campos estratégicos
    competitor_analysis = models.JSONField(default=dict, blank=True)
    keywords = models.JSONField(default=list, blank=True)
    estimated_budget = models.CharField(max_length=50, blank=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['platform', 'created_at']),
        ]
    
    def __str__(self):
        return f"{self.product_title} - {self.platform} - {self.created_at}"


class MarketingTemplate(models.Model):
    """Plantillas predefinidas para diferentes nichos"""
    name = models.CharField(max_length=200)
    category = models.CharField(max_length=100)
    platform = models.CharField(max_length=50)
    template_content = models.JSONField()
    success_rate = models.FloatField(default=0.0)
    times_used = models.IntegerField(default=0)
    
    class Meta:
        ordering = ['-success_rate', '-times_used']


class CompetitorAnalysis(models.Model):
    """Análisis de competidores"""
    analysis = models.ForeignKey(AnalysisHistory, on_delete=models.CASCADE)
    competitor_url = models.URLField()
    competitor_name = models.CharField(max_length=200)
    strengths = models.JSONField(default=list)
    weaknesses = models.JSONField(default=list)
    strategies = models.JSONField(default=list)
    created_at = models.DateTimeField(default=timezone.now)